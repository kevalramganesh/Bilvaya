// Dark mode toggle — in-memory state (localStorage is blocked in sandboxed iframes)
(function(){
  const t = document.querySelector('[data-theme-toggle]');
  const r = document.documentElement;
  let d = matchMedia('(prefers-color-scheme:dark)').matches ? 'dark' : 'light';
  r.setAttribute('data-theme', d);
  function iconFor(mode){
    return mode === 'dark'
      ? '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>'
      : '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';
  }
  if(t){
    t.innerHTML = iconFor(d);
    t.addEventListener('click', ()=>{
      d = d === 'dark' ? 'light' : 'dark';
      r.setAttribute('data-theme', d);
      t.innerHTML = iconFor(d);
      t.setAttribute('aria-label','Switch to ' + (d==='dark'?'light':'dark') + ' mode');
    });
  }

  // Sticky header shadow
  const header = document.querySelector('.site-header');
  if(header){
    const onScroll = () => header.classList.toggle('is-scrolled', window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll, {passive:true});
  }

  // Mobile menu
  const menuBtn = document.querySelector('[data-menu-open]');
  const menuClose = document.querySelector('[data-menu-close]');
  const drawer = document.querySelector('.mobile-nav');
  if(menuBtn && drawer){
    menuBtn.addEventListener('click', ()=> drawer.classList.add('is-open'));
    menuClose && menuClose.addEventListener('click', ()=> drawer.classList.remove('is-open'));
    drawer.querySelectorAll('a').forEach(a => a.addEventListener('click', ()=> drawer.classList.remove('is-open')));
  }

  // Reveal on scroll
  const io = new IntersectionObserver((entries)=>{
    entries.forEach(e=>{
      if(e.isIntersecting){ e.target.classList.add('is-visible'); io.unobserve(e.target); }
    });
  }, {threshold:.12, rootMargin:'0px 0px -60px 0px'});
  document.querySelectorAll('.reveal').forEach(el=>io.observe(el));

  // Form (front-end only demo)
  const form = document.querySelector('[data-contact-form]');
  if(form){
    form.addEventListener('submit', (e)=>{
      e.preventDefault();
      const status = form.querySelector('[data-form-status]');
      if(status){
        status.textContent = 'Thank you. Our team will respond within one business day.';
        status.style.color = 'var(--color-accent)';
      }
      form.reset();
    });
  }
})();
